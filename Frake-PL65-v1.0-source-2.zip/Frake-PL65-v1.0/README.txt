FRAKE THE SNAKE v1.0
Noahsoft PL/65 - Atari XL/XE

START
Use a 64 KB Atari XL/XE with BASIC disabled. Load Frake-PL65-v1.0.xex.
Joystick in port 1. PAL and NTSC are supported, including XL OS 1.3.
The main playfield uses five-color character mode. Players color the
flag, eggs and room furnishings.

PLAY
Collect five eggs in each of the sixteen rooms. Clear them all, then
leave through the east door of the throne room.

Each valid direction change moves Frake immediately. Holding a direction
continues at the regular pace. Reverse turns are ignored.
Frake starts sixteen segments long and grows six segments per egg.
Movement speeds up as you clear more rooms.

Walls, closed doors, furniture and your own body cost a life. You start
with four lives. Cleared rooms and collected eggs survive a lost life.
Clearing a room opens its connecting doors in both directions.

Each egg scores 100 points plus a time bonus of up to 10. Clearing a room
adds 25. Every four cleared rooms earns a life, up to nine. Escape adds
200 plus 20 per remaining life. The best score lasts until you quit.

CONTROLS
Joystick directions: steer.
Fire, G or START at the title: start. I: instructions.
Fire or P during play: pause; press again to resume.
M: castle map. Fire or M returns to play.
Fire after the result screen: new game.
Q at a result screen: title. Q at the title: return to the loader or DOS.

ROOMS
The castle is four rooms wide and four rooms deep.
 1 Gatehouse       2 Courtyard       3 Armory          4 Curtain Room
 5 Treasure Room   6 Great Hall      7 Kitchen         8 Pantry
 9 Library        10 Chapel        11 Barracks       12 Dungeon
13 Cellar         14 Statue Gallery 15 Guard Tower    16 Throne Room

FILES
src/        Game and room names.
lib/        Display, room data, graphics and sound routines.
atascii/    Source with Atari line endings, ready for PL65.COM.
text/       Individual text copies.
SOURCE.txt  All source and documentation in one file.
docs/       Build instructions and library reference.

BUILD
Copy all files from atascii/ to D: and compile FRAKE.P65 with Noahsoft's
PL65.COM. Enable the runtime and autorun. See docs/BUILD.txt.

CREDITS
Original FRAKE game: Mark2006.
Worm Of Bemer: Stephen D. Fultz, COMPUTE! issue 47, April 1984.
Noahsoft PL/65 runtime routines: Copyright (C) 1987 Noahsoft.
